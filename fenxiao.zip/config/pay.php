<?php

return [
        'alipay' => [
            'app_id' => '2021002114619353',
//            'ali_public_key' => 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCnxj/9qwVfgoUh/y2W89L6BkRAFljhNhgPdyPuBV64bfQNN1PjbCzkIM6qRdKBoLPXmKKMiFYnkd6rAoprih3/PrQEB/VsW8OoM8fxn67UDYuyBTqA23MML9q1+ilIZwBC2AQ2UBVOrFXfFl75p6/B5KsiNG9zpgmLCUYuLkxpLQIDAQAB',
            'private_key' => 'MIIEowIBAAKCAQEAvgwfNRZYl81Z/Pawz/mGg9dLILfr81AA80DJ9smWKdGNRRGMp3OnEABXj5QqUn6D4QfvvLoiNEVLUCORoaotfMyo6J3zxBecYuCdhb91I8Cc6hprysNaWLtT49Fl69LSu29/8HwWoBtpyJAnepOvQpwD9ldfSqm+7SiS+SNCNNiL2j+YKtrWnRJXkK83m/Q3EIxFNF1Aq0nD9WvtJ9DpBpEqxyD/Olg87D+HO63aOd+MGV21w5SiPMOE2m23ur16XT9GgYH7Gc203rwiL1tzvzEvp6kQVU2yZZjrnGZVlalURPXCQeypoCtUfOeD37qvpZlXiHQuUabueA2bNNo3SwIDAQABAoIBAHKTblEcKsdCV6lptMl9/zoHF1UfbVIgfqIpAloVyMFng8sLPIhL8oF0I1X9ltJrUejeVwuqECsBR9mFyCv2JDxkSsULTUaAkZkPIAjdl6q5WiDNUwVIZ3StY3Mq8E6PqNq16yU6Oo3GWS1As3x0AyqeUsk2fc3OrrveRVWMi0K97FjPt5jVXPl+RCKtx271iJQOc8sp3sQqrCaXXeAFsE9LRv4pm1Nw6sxI6Uqfxkx1NGdmndBcjn1NkxEe+iUURPhwGTubQJezMtKZfjaaqaMnAZ2xfFM46RDWnlKl1ncbkb/tkh1nRfAikVKSDHz9kBnPadrEPicRvKtcfLILIdECgYEA7NAtLcUWoCyj4DoKJ/0oYirG5zq5XcLgatkgf99/WmV9q/+MQD2/yfL/2JqNjyw0QFlYkM+KmshrRkwiCeUdrF/KjFLMJZ4ehSBoFby51SJsVnBj7YQOQkxgTedM2vIyaTrIMlvnTym4KQGrWKwgwKPs3dq09N5xuxCvF/c4WkMCgYEAzXH1iqdoVraKnT+oNzW/wDtFOOdTXPt9bNM2WNTjSQyRoxe86FE4B8y7ZHVb0XM6Oma8iXV6eGNSyv6hwOv+h8UyUUk2rZxDXNO9dB73UzISV2GIhQf2k8tKkaKKwsPzeAfUlt7M8XOW2reXynXTMJYv0vELvpA3SEXOTfcbclkCgYADTI8kkRdUmeqaiBR2JCe43mGw/PdyH/Hiay3xuhpbFwjeKYw5pOKUHKeFy/lm4jXEI7qBIfMLXvlnnE3pF2EHcroupESlzYMdVas9ikiIeJdLyPsLZwiP0eKRk0RV1IPxRVleojshtjITmCtb6+H07ROyr4ZP1v18nqnhypblYwKBgGCfs1MV7y2xRro0YUIuJlQbzC+6JGv73/6Zy9q1rXwCzFA/btp4sHiCorPZumhk4ELtZMjllsceN6c/YQYiOCDU7xhp7axzbP8wms8NbVcUmqm8NoASwba7CwQ5xTda/5w5WpPmj88ThSSy6lIPXldgm3eDZPmoTEfShPgIO0FpAoGBAL3Np3c5OGWkhV6R087KUKiq48/TKk3Dh23PnFrGlMBfAYQcDStzPtErdQJ3zxlHA11qkefgT479t0fGe5SWazXia0x7PxUKIMR7tLt5/o6ITl0YSn6/9Di9vi52lmrBARWABkJkqCh0+BUP8Z9jId6pM8UXpp/Ttot/ZFuZ9rVD',
            'app_cert_public_key' => base_path() . '/public/cert/appCertPublicKey_2021002114619353.crt', //应用公钥证书路径
            'ali_public_key'     =>  base_path() . '/public/cert/alipayCertPublicKey_RSA2.crt', //支付宝公钥证书路径
            'alipay_root_cert'    =>  base_path() . '/public/cert/alipayRootCert.crt', //支付宝根证书路径
            'log' => [ // optional
                'file' => './logs/alipay.log',
                'level' => 'info', // 建议生产环境等级调整为 info，开发环境为 debug
                'type' => 'single', // optional, 可选 daily.
                'max_file' => 30, // optional, 当 type 为 daily 时有效，默认 30 天
            ],
            'http' => [ // optional
                'timeout' => 5.0,
                'connect_timeout' => 5.0,
                // 更多配置项请参考 [Guzzle](https://guzzle-cn.readthedocs.io/zh_CN/latest/request-options.html)
            ],
//            'mode' => 'dev', // optional,设置此参数，将进入沙箱模式
        ],
];
