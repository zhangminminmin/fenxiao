<div class="col-sm-3">
    <div class="row">
        <a style="padding:3px 5px;float:right;margin-right:10px;" href="?do=backup" class="btn btn-default"><i class="fa fa-floppy-o"></i>&nbsp;<?php echo $saveTitle; ?></a>
    </div>
    <div class="row">
        <?php $__currentLoopData = $tree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title => $fields): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label class="control-label">
            <i class="fa fa-plus-square-o"></i>&nbsp;<?php echo $title; ?>

            <?php if($tabsEdit): ?>
            <a href='<?php echo $tabsEdit; ?>' style='margin-left:5px;' title='<?php echo $editTitle; ?>'>
                <i class='fa fa-edit'></i>
            </a>
            <?php endif; ?>
        </label>

        <div class="dd">
            <ol class="dd-list" style="left:2%;">
                <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($field['options']) && \Illuminate\Support\Arr::get($field['options'],'divide') =='befor'): ?>
                <li style="margin:5px 0;text-align:center;"><i class="fa fa-scissors"></i> - - - - - - - - - - - - - -</li>
                <?php endif; ?>
                <li title="<?php echo $field['name']; ?>" style="border:1px dashed #c1c1c1;padding:5px;margin-bottom:5px;color:#666;overflow:hidden;" class="dd-item configx-<?php echo $field['id']; ?>" data-id="<?php echo $field['id']; ?>">
                    <span class="dd-drag"><i class="fa fa-arrows"></i>&nbsp;<?php echo $field['label']; ?>-</span><b>[<?php echo $field['type_name']; ?>]</b>
                    <span class="pull-right dd-nodrag">
                        <a title="<?php echo $editTitle; ?>" href="<?php echo $field['href']; ?>"><i class="fa fa-edit"></i></a>
                        <?php if($field['id'] != $current_id): ?>
                        <a style="margin-left:5px;" title="<?php echo $editTitle; ?>" onclick="delConfig(<?php echo $field['id']; ?>);" href="javascript:;"><i class="fa fa-trash-o"></i></a>
                        <?php else: ?>
                        <a style="margin-left:5px;cursor: not-allowed;" title="<?php echo $editTitle; ?>" href="javascript:;"><i class="fa fa-trash-o"></i></a>
                        <?php endif; ?>
                    </span>
                    <?php if(isset($field['tds']) && count($field['tds'])): ?>
                    <ul class="dd-list">
                        <?php $__currentLoopData = $field['tds']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li title="<?php echo $td['name']; ?>" style="border-bottom:1px dashed #c1c1c1;padding:2px;margin-bottom:4px;overflow:hidden;" class="configx-<?php echo $td['id']; ?>"><span><?php echo $td['label']; ?></span>-<b>[<?php echo $td['type_name']; ?>]</b>
                            <a class="pull-right dd-nodrag" title="<?php echo $editTitle; ?>" href="<?php echo $td['href']; ?>"><i class="fa fa-edit"></i></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
                </li>
                <?php if(isset($field['options']) && \Illuminate\Support\Arr::get($field['options'],'divide') =='after'): ?>
                <li style="margin:5px 0;text-align:center;"><i class="fa fa-scissors"></i> - - - - - - - - - - - - - -</li>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<script>
    $(function() {
        var current_id = parseInt('<?php echo $current_id; ?>');

        if(current_id > 0)
        {
            $('li.configx-' + current_id).addClass('configx-active').css({'color':'green','border-color':'green'});
        }

        $('.dd').nestable({
            handleClass: 'dd-drag'
        }).on('change', function() {
            var data = $(this).nestable('serialize');
            $.ajax({
                url: '<?php echo e($call_back, false); ?>',
                type: "POST",
                data: {
                    data: data,
                    _token: LA.token,
                    _method: 'PUT'
                },
                success: function(data) {
                    toastr.success(data.message);
                }
            });
        });
        $('.input-group .input-group-btn').siblings().dblclick(function() {
            return false; //block numbox click
        });
    });

    function delConfig(id) {
        swal({
            title: "<?php echo e($deleteConfirm, false); ?>",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "<?php echo e($confirm, false); ?>",
            showLoaderOnConfirm: true,
            cancelButtonText: "<?php echo e($cancel, false); ?>",
            preConfirm: function() {
                return new Promise(function(resolve) {
                    $.ajax({
                        method: 'post',
                        url: '<?php echo e($del_url, false); ?>/' + id,
                        data: {
                            _method: 'delete',
                            _token: LA.token,
                        },
                        success: function(data) {
                            $.pjax.reload('#pjax-container');

                            resolve(data);
                        }
                    });
                });
            }
        }).then(function(result) {
            var data = result.value;
            if (typeof data === 'object') {
                if (data.status) {
                    swal(data.message, '', 'success');
                } else {
                    swal(data.message, '', 'error');
                }
            }
        });
    }
</script>
<?php /**PATH D:\work\fenxiao\vendor\ichynul\configx\src/../resources/views/tree.blade.php ENDPATH**/ ?>