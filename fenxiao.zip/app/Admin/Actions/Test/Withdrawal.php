<?php

namespace App\admin\Actions\Test;

use Encore\Admin\Actions\Action;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Encore\Admin\Actions\RowAction;
use Yansongda\LaravelPay\Facades\Pay;
class Withdrawal extends RowAction
{
    protected $selector = '.withdrawal';
    public $name = '提现审核';
    public function handle(Model $model,Request $request)
    {
        $id = $request->get('_key');
        $info = \App\Models\Withdrawal::where('id', $id)->first();
        if ($info['status'] != 1) {
            return $this->response()->error('订单已经审核 无须重复操作')->refresh();
        }else{
            $data = ['status' => 2,];
            $order = [
                'out_biz_no' => "zfb" . time(),
                'trans_amount' => $info['money'],
                'product_code' => 'TRANS_ACCOUNT_NO_PWD',
                'biz_scene' => 'DIRECT_TRANSFER',
                'payee_info' => [
                    'identity' => $info['alipaycode'],
                    'identity_type' => 'ALIPAY_LOGON_ID',
                    'name' => $info['realname'],
                ],
            ];


//            print_r(config('pay.alipay'));die;

            $result = Pay::alipay()->transfer($order);
            print_r($result);die;

            $edit = \App\Models\Withdrawal::where('id', $id)->update($data);
            return $this->response()->success('支付宝打款成功')->refresh();

        }
    }

    public function html()
    {
        return <<<HTML
        <a class="btn btn-sm btn-default withdrawal"></a>
HTML;
    }
}
