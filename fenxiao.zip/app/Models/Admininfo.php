<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Admininfo extends Model
{
    //
    public $table = 'admin_config';

}
